window.forge.debug = true;

var forecast = {
	city: "Mountain View, CA",
	forecast_date: "2011-08-09"
};

var currentConditions = {
	condition: "Clear",
	temp_f: "73",
	humidity: "Humidity: 57%",
	icon: "resources/sunny.gif",
	wind_condition: "Wind: N at 9 mph"
};

var forecastConditionMaker = function(day_of_week, low, high, icon, condition) {
	return {
		day_of_week: day_of_week,
		low: low,
		high: high,
		icon: icon,
		condition: condition
	}
};

var tuesdayConditions = forecastConditionMaker("Tue", "58","72", "resources/mostly_sunny.gif","Clear");
var wednesdayConditions = forecastConditionMaker("Wed", "58", "72", "resources/sunny.gif", "Clear");
var thursdayConditions = forecastConditionMaker("Thu", "56", "72", "resources/chance_of_rain.gif", "Chance of Rain");
var fridayConditions = forecastConditionMaker("Fri", "58", "74", "resources/sunny.gif", "Clear");

var mountainViewForecast = {
    forecast: forecast,
    currentConditions: currentConditions,
    forecastConditions: [tuesdayConditions, wednesdayConditions, thursdayConditions, fridayConditions]
};

forge.logging.log(mountainViewForecast);

