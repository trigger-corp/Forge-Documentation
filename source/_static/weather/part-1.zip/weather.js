function ForecastInformation(city, forecastDate) {
    this.city = city;
    this.forecastDate = forecastDate;

    return this;
};

function CurrentConditions(condition, tempF, humidity, iconSrc, windCondition) {
    this.condition = condition;
    this.tempF = tempF;
    this.humidity = humidity;
    this.img = iconSrc;
    this.windCondition = windCondition;

    return this;
};

function ForecastConditions(dayOfWeek, low, high, imgSrc, condition){
    this.dayOfWeek = dayOfWeek;
    this.low = low;
    this.high = high;
    this.img = imgSrc;
    this.condition = condition;

    return this;
};

function WeatherForecast(forecast, currentConditions, forecastConditions) {
    this.forecast = forecast;
    this.currentConditions = currentConditions;
    this.forecastConditions = forecastConditions;

    return this;
};

var forecast = new ForecastInformation("Mountain View, CA", "2011-08-09");
var currentConditions = new CurrentConditions("Clear", "73", "Humidity: 57%", "resources/sunny.gif", "Wind: N at 9 mph");
var tuesdayConditions = new ForecastConditions("Tue", "58","72", "resources/mostly_sunny.gif","Clear");
var wednesdayConditions = new ForecastConditions("Wed", "58", "72", "resources/sunny.gif", "Clear");
var thursdayConditions = new ForecastConditions("Thu", "56", "72", "resources/chance_of_rain.gif", "Chance of Rain");
var fridayConditions = new ForecastConditions("Fri", "58", "74", "resources/sunny.gif", "Clear");

var mountainViewForecast = new WeatherForecast(forecast, currentConditions,
    [tuesdayConditions, wednesdayConditions, thursdayConditions, fridayConditions]);

forge.logging.log(mountainViewForecast)