forge.logging.info('Hello World, this is JavaScript');
