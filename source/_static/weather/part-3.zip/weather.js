function ForecastInformation(city, forecastDate) {
    this.city = city;
    this.forecastDate = forecastDate;

    return this;
};

function CurrentConditions(condition, tempF, humidity, iconSrc, windCondition) {
    this.condition = condition;
    this.tempF = tempF;
    this.humidity = humidity;
    this.img = iconSrc;
    this.windCondition = windCondition;

    return this;
};

function ForecastConditions(dayOfWeek, low, high, imgSrc, condition){
    this.dayOfWeek = dayOfWeek;
    this.low = low;
    this.high = high;
    this.img = imgSrc;
    this.condition = condition;

    return this;
};

function WeatherForecast(forecast, currentConditions, forecastConditions) {
    this.forecast = forecast;
    this.currentConditions = currentConditions;
    this.forecastConditions = forecastConditions;

    return this;
};

function populateWeatherConditions(weatherCondition){
    forge.logging.log('beginning populating weather conditions');

    $('#forecast_information_tmpl').tmpl(weatherCondition.forecast).appendTo($('#forecast_information'));
    forge.logging.log('finished populating forecast information');

    $('#current_conditions_tmpl').tmpl(weatherCondition.currentConditions).appendTo($('#current_conditions'));
    forge.logging.log('finished populating current conditions');

    $('#forecast_conditions_tmpl').tmpl(weatherCondition.forecastConditions).appendTo($('#forecast_conditions table tr'));
    forge.logging.log('finished populating forecast conditions');

    forge.logging.log('finished populating weather conditions');
};

$(function(){
    getWeatherInfo('Boston', populateWeatherConditions);
});

function getWeatherInfo(location, callback){
    forge.logging.log('[getWeatherInfo] getting weather for for '+location);
    forge.request.ajax({
        url:"http://www.google.com/ig/api?weather="+encodeURIComponent(location),
        dataType: 'xml',
        success: function(data, textStatus, jqXHR){
            forge.logging.log('[getWeatherInfo] success');
            var weatherObj = buildWeather(data);
            callback(weatherObj);
        },
        error: function(jqXHR, textStatus, errorThrown){
            forge.logging.log('ERROR! [getWeatherInfo] '+textStatus);
        }
    })
};

function buildForecastInformation(forecastInformation){
    forge.logging.log('[buildForecastInformation] building internal forecast information object');

    var city = $('city', forecastInformation).attr('data');
    var forecastDate = $('forecast_date', forecastInformation).attr('data');

    return new ForecastInformation(city, forecastDate);
};

function formatImgSrc(imgURL){
    return 'resources/'+/[a-z_]*.gif/.exec(imgURL)[0];
};

function buildCurrentCondition(currentCondition){
    forge.logging.log('building internal current conditions object');

    var condition = $('condition', currentCondition).attr('data');
    var tempF = $('temp_f', currentCondition).attr('data');
    var humidity = $('humidity', currentCondition).attr('data');
    var imgURL = $('icon', currentCondition).attr('data');
    var img = formatImgSrc(imgURL);
    var windCondition = $('wind_condition', currentCondition).attr('data');

    return new CurrentConditions(condition, tempF, humidity, img, windCondition);
};

function buildForecastConditions(forecastConditions){
    var convertedForecastConditions = [];
    $(forecastConditions).each(function(index, element){
        convertedForecastConditions.push(buildForecastCondition(element));
    });
    return convertedForecastConditions;
};

function buildForecastCondition(forecastCondition){
    forge.logging.log('[buildForecastCondition] building internal forecast condition');

    var dayOfWeek = $('day_of_week', forecastCondition).attr('data');
    var low = $('low', forecastCondition).attr('data');
    var high = $('high', forecastCondition).attr('data');
    var imgURL = $('icon', forecastCondition).attr('data');
    var img = formatImgSrc(imgURL);
    var condition = $('condition', forecastCondition).attr('data');

    return new ForecastConditions(dayOfWeek, low, high, img, condition);
};

function buildWeather(parsedData){
    forge.logging.log('[buildWeather] converting data to internal representation');

    var forecastInformation = buildForecastInformation($('forecast_information', parsedData));
    var currentConditions = buildCurrentCondition($('current_conditions', parsedData))
    var forecastConditions = buildForecastConditions($('forecast_conditions', parsedData));
    return new WeatherForecast(forecastInformation, currentConditions, forecastConditions);
};

