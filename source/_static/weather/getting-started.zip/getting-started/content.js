function writeGreeting(name){
    window.forge.logging.log('Hello '+name);
};
writeGreeting('Sahil');