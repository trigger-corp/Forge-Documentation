var oldProfile = new RegExp("\\.facebook\\.com/profile\\.php\\?id=(\\d+)");
var newProfile = new RegExp("\\.facebook\\.com/([A-Za-z0-9\\.]+)(\\?.+)?$");
var ignoreProfiles = new RegExp("\\.php$");

var oldProfileM = oldProfile.exec(document.URL),
  newProfileM = newProfile.exec(document.URL),
  personID = undefined;
if (oldProfileM) {
  // URL is like www.facebook.com/profile.php?id=123456789
  var personID = oldProfileM[1];
} else if (newProfileM) {
  // URL is like www.facebook.com/profile.name ...
  var personID = newProfileM[1];
  if (ignoreProfiles.exec(personID)) {
    // ... but it's a system page (like the login screen)
    var personID = undefined;
  }
}

if (typeof personID !== "undefined") {
  handleProfilePage(personID);
}

function handleProfilePage(personID) {
  alert("On a Facebook profile page");
  forge.prefs.get("fb_notes", function(notes) {
    // set to null when no preference yet set
    var existingNotes = notes === null? {}: notes;
    
    if (existingNotes[personID] === undefined) {
      existingNotes[personID] = "";
    }
    var noteEl = $("<div class='fb-note' style='z-index: 1000; position: absolute'>"+
      "<a class='fb-close-note'>X</a>"+
      "<textarea class='fb-note-content'></textarea>"+
      "<a class='save-note'>save note</a>"+
      "</div>");

    $("a.save-note", noteEl).click(function() {
      // save textarea content into the existingNotes object we read before
      existingNotes[personID] = $(".fb-note-content", noteEl).val();
      // forge.prefs.set is the inverse of forge.prefs.get
      forge.prefs.set("fb_notes", existingNotes);
      alert("Note saved!");
    });
    
    $("a.fb-close-note", noteEl).click(function() {
      $(".fb-note").remove();
    });

    $(".fb-note-content", noteEl).val(existingNotes[personID]);
    $("body").first().prepend(noteEl);
  });
}